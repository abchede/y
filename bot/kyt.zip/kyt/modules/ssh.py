import requests
from kyt import *

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
    async def ssh_member_manager(event):
        inline = [
            [Button.inline(" TRIAL SSH ", "trial-ssh-member"),
             Button.inline(" CREATE SSH ", "create-ssh-member")],
            [Button.inline(" LOGIN SSH ", "login-ssh-member"),
            Button.inline(" SHOW USER SSH ", "show-ssh-member")],
[Button.inline(" RENEW SSH ", "renew-ssh-member")],
            [Button.inline("‹ Main Menu ›", "menu")]]
        
        location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**━━━━━━━━━━━━━━━━**
`•ssh member manager•`
**━━━━━━━━━━━━━━━━**
**» Service:** `SSH`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{location_info["isp"]}`
**» Country:** `{location_info["country"]}`
**» 🛂@abecasdee**
**━━━━━━━━━━━━━━━━**
"""
        await event.edit(msg, buttons=inline)

    async def ssh_admin_manager(event):
        inline = [
            [Button.inline(" TRIAL SSH ", "trial-ssh"),
             Button.inline(" CREATE SSH ", "create-ssh")],
             [Button.inline(" DELETE SSH ", "delete-ssh"),
            Button.inline(" LOGIN SSH ", "login-ssh")],
            [Button.inline(" SHOW ALL USER ", "show-ssh"),
Button.inline(" RENEW SSH ", "renew-ssh")],
            [Button.inline("‹ Main Menu ›", "menu")]]
        
        location_info = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**━━━━━━━━━━━━━━━━**
`•ssh admin manager•`
**━━━━━━━━━━━━━━━━**
**» Service:** `SSH`
**» Hostname/IP:** `{DOMAIN}`
**» ISP:** `{location_info["isp"]}`
**» Country:** `{location_info["country"]}`
**» 🛂@abecasdee13**
**━━━━━━━━━━━━━━━━**
"""
        await event.edit(msg, buttons=inline)

    user_id = str(event.sender_id)
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await ssh_admin_manager(event)
        else:
            await ssh_member_manager(event)
    except Exception as e:
        print(f'Error: {e}')

