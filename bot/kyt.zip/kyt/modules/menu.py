from kyt import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/SatanTech/ResP/master/statushariini"

response = requests.get(url)


if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline(" SSH MENU ", "ssh")],
                    [Button.inline(" VMESS MENU ", "vmess-member"),
                     Button.inline(" VLESS MENU ", "vless-member")],
                    [Button.inline(" TROJAN MENU ", "trojan-member"),
                     Button.inline(" SDWSK MENU", "shadowsocks-member")],
                    [Button.inline(" NOOBZ MENU", "noobzvpn-member")],
                    [Button.url(" CHANNEL TELE ", "https://t.me/satanofficiall"),
                     Button.inline(" TOP UP MANUAL", f"topup")]
                ]

                member_msg = f"""
**━━━━━━━━━━━━━━━━**
**Notice : {response.text}**
**━━━━━━━━━━━━━━━━**
**INFORMATION ACCOUNT**

**» Your ID : `{user_id}`
**» Balance : ** `RP.{saldo_aji}`
**━━━━━━━━━━━━━━━━**

**» 🎲Harga SSH    IDR.10.000 **
**» 🎲Harga VMESS  IDR.15.000 **
**» 🎲Harga VLESS  IDR.15.000 **
**» 🎲Harga TROJAN IDR.15.000 **

**━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
                    [Button.inline(" SSH MENH ", "ssh")],
                    [Button.inline(" VMESS MENU ", "vmess"),
                     Button.inline(" VLESS MENU ", "vless")],
                    [Button.inline(" TROJAN MENU ", "trojan"),
                     Button.inline(" SDWSK MENU ", "shadowsocks")],
                    [Button.inline(" NOOBZ MENU ", "noobzvpns"),
                     Button.inline(" ADD MEMBER", "registrasi-member"),
                     Button.inline(" DEL MEMBER", "delete-member")],
                     [Button.inline(" LIST MEMBER ", "show-user")],
                    [Button.inline(" ADD SALDO MEMBER", "addsaldo")],
                    [Button.inline(" VPS INFO", "info"),
                     Button.inline(" SETTINGS", "setting")],
                ]

                admin_msg = f"""
**━━━━━━━━━━━━━━━━**
**Notice : {response.text}**
**━━━━━━━━━━━━━━━━**
**INFORMATION ACCOUNT**

**» Your ID : `{user_id}`

**━━━━━━━━━━━━━━━━**

**» 🎲Harga SSH    IDR.10.000 **
**» 🎲Harga VMESS  IDR.15.000 **
**» 🎲Harga VLESS  IDR.15.000 **
**» 🎲Harga TROJAN IDR.15.000 **

**━━━━━━━━━━━━━━━━**
**» 🎲Total user in databases:** `{get_user_count()}`
**━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'```Anda belum terdaftar, silahkan registrasi```',
            buttons=[[(Button.inline("Registrasi", "registrasi"))]]
        )

